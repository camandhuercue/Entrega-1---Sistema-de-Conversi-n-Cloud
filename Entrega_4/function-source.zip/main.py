import base64
import functions_framework
from queue_api.utils import get_tasks
from tasks import comprimir_zip, comprimir_7z, comprimir_bz2, comprimir_tar, update_task, send_email
from os import path, mkdir, remove, rename
import shutil
import time
import json
from google.cloud import storage

@functions_framework.cloud_event
def hello_pubsub(cloud_event):
    data = base64.b64decode(cloud_event.data["message"]["data"]).decode("utf-8")
    print(data)
    data = json.loads(data)
    #client = storage.Client.from_service_account_json('./key.json')
    client = storage.Client()
    bucket_name = "unsuperbucketparaelproyecto"
    T = get_tasks(data['uuid'])
    bucket = client.get_bucket(bucket_name)
    print("Se llama la tarea de UUID: {}".format(data['uuid']))
    for t in T:
        Path = t['path']
        file_name = t['filename']
        ID = t['id']
        blob_name = Path
        blob = bucket.blob(blob_name)
        output_file_name = ID
        algo = blob.download_as_bytes()
        with open(output_file_name, "wb") as binary_file:
            binary_file.write(algo)
        if t['format'] == "ZIP":
            comprimir_zip(file_name, file_name + '.zip', Path, ID, bucket)
            #send_email.delay(email, t['filename'], t['id'])
            update_task(t['id'])
        if t['format'] == "7Z":
            comprimir_7z(file_name, file_name + '.7z', Path, ID, bucket)
            #send_email.delay(email, t['filename'], t['id'])
            update_task(t['id'])
        if t['format'] == "BZ2":
            comprimir_bz2(file_name, file_name + '.bz2', Path, ID, bucket)
            #send_email.delay(email, t['filename'], t['id'])
            update_task(t['id'])
        if t['format'] == "TGZ":
            comprimir_tar(file_name, file_name + '.tgz', Path, 'zip', ID, bucket)
            #send_email.delay(email, t['filename'], t['id'])
            update_task(t['id'])
        if t['format'] == "TBZ2":
            comprimir_tar(file_name, file_name + '.tbz2', Path, 'bz2', ID, bucket)
            #send_email.delay(email, t['filename'], t['id'])
            update_task(t['id'])

    print("Fin de la funcion")